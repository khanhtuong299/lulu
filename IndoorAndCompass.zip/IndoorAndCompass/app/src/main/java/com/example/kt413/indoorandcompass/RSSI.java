package com.example.kt413.indoorandcompass;

/**
 * Created by kt413 on 11/24/2017.
 */

public class RSSI {
    public int ID;
    public  float x;
    public  float y;
    public float RSSI_coship4;
    public  float RSSI_coship5;
    public float RSSI_TTI;
    public float RSSI_Telecom;
    public String connect;

    public RSSI(int ID, float x, float y, float RSSI_coship4, float RSSI_coship5, float RSSI_TTI, float RSSI_Telecom, String connect) {
        this.ID = ID;
        this.x = x;
        this.y = y;
        this.RSSI_coship4 = RSSI_coship4;
        this.RSSI_coship5 = RSSI_coship5;
        this.RSSI_TTI = RSSI_TTI;
        this.RSSI_Telecom = RSSI_Telecom;
        this.connect = connect;
    }
}
