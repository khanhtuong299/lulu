package com.example.kt413.indoorandcompass;

import android.os.CountDownTimer;

/**
 * Created by kt413 on 11/23/2017.
 */

public class AnimationCanvas {

    public Canvas canvas;


    float xOffset=800;
    float yOffset=800;

    public AnimationCanvas(Canvas canvas) {
        this.canvas = canvas;
    }

    public void firstPoint(float a, float b){
        float coorX=xOffset-a;
        float coorY=yOffset-b;
        canvas.matrix.postTranslate(coorX,coorY);
        canvas.invalidate();
    }

    public void netxPoint(final float a_old, final float b_old, final float a_new,final float b_new, final float step){
        CountDownTimer countDownTimer=new CountDownTimer(2000,8) {
            float dx=-a_new+a_old;
            float dy=-b_new+b_old;
            long distance_long=(long)Math.sqrt((double)(dx*dx+dy*dy));
            float distance=(float)distance_long;
            float xAdd=dx*step/distance;
            float yAdd=dy*step/distance;
            int i_Animation=0;
            @Override
            public void onTick(long l) {
                if(i_Animation<distance/step){
                    canvas.matrix.postTranslate(xAdd,yAdd);
                    canvas.invalidate();
                    i_Animation++;
                }
            }

            @Override
            public void onFinish() {

            }
        };
        countDownTimer.start();
    }

}
