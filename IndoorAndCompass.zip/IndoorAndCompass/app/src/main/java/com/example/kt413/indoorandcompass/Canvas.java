package com.example.kt413.indoorandcompass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by kt413 on 11/23/2017.
 */

public class Canvas extends View {

    Paint mPaint;
    Paint fPaint;
    Paint cPaint;
    Paint flash;
    Matrix matrix;
    float fRadius;
    float radious;
    float flashR;
    final float p_offsetX = 0;
    final float p_offsetY = 0;
    float degree=0;
    Bitmap mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.map_ver4);
    int ngang=mBitmap.getWidth();
    int doc=mBitmap.getHeight();
    float ngang_or=800*2;
    float doc_or=800*2;



    public Canvas(Context context) {
        super(context);
        initPaint();
    }

    public Canvas(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initPaint();
    }

    public Canvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initPaint();
    }

    public Canvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initPaint();
    }
    private void initPaint(){
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(30);
        //**************************************************

        //**************************************************
        matrix = new Matrix();
        //***************************************************
        fPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
        fPaint.setColor(Color.argb(70,41,98,255));
        //***************************************************
        fRadius=100;
        radious=25;
        flashR=10;
        //***************************************************
        cPaint = new Paint();
        cPaint.setColor(Color.BLUE);
        cPaint.setShadowLayer(50, 0, +50, Color.BLUE);
        cPaint.setStyle(Paint.Style.STROKE);
        cPaint.setStrokeWidth(5);

        flash=new Paint(Paint.ANTI_ALIAS_FLAG);
        flash.setColor(Color.argb(190,41,98,255));
        matrix.postScale((float)(ngang_or/ngang),(float)(doc_or/doc));
        matrix.postTranslate(-ngang_or/2,-doc_or/2);


    }

    @Override
    protected void onDraw(android.graphics.Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(getWidth()/2,getHeight()/2);
        canvas.rotate(degree);
        canvas.drawBitmap(mBitmap,matrix,mPaint);
        canvas.drawCircle(p_offsetX,p_offsetY,radious,mPaint);
        //canvas.drawCircle(600,700,radious,mPaint);
        //canvas.drawCircle(-600,-700,radious,mPaint);
        //canvas.drawCircle(89-600,240-700,radious,mPaint);
        canvas.drawCircle(p_offsetX,p_offsetY,fRadius,fPaint);
        canvas.drawCircle(p_offsetX,p_offsetY,fRadius,cPaint);
        canvas.drawCircle(p_offsetX,p_offsetY,flashR,flash);
    }
}
