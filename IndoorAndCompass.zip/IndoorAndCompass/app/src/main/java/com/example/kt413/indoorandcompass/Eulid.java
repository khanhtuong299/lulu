package com.example.kt413.indoorandcompass;

import java.util.ArrayList;

/**
 * Created by kt413 on 11/24/2017.
 */

public class Eulid {
    public ArrayList<RSSI> databaseRSSI;
    public ArrayList<Integer> rssi_Coship4;
    public ArrayList<Integer> rssi_Coship5;
    public ArrayList<Integer> rssi_TTI;
    public ArrayList<Integer> rssi_Telecom;

    public Eulid(ArrayList<RSSI> databaseRSSI, ArrayList<Integer> rssi_Coship4, ArrayList<Integer> rssi_Coship5,
                 ArrayList<Integer> rssi_TTI, ArrayList<Integer> rssi_Telecom) {
        this.databaseRSSI = databaseRSSI;
        this.rssi_Coship4 = rssi_Coship4;
        this.rssi_Coship5 = rssi_Coship5;
        this.rssi_TTI = rssi_TTI;
        this.rssi_Telecom = rssi_Telecom;
    }

    public boolean check(){
        if ((rssi_Coship4.size()==0)&&(rssi_Coship5.size()==0)&&(rssi_TTI.size()==0)&&(rssi_Telecom.size()==0))
            return false;
        else
            return true;
    }
    public float avg(ArrayList<Integer>A){
        int sum=0;
        float result=0;
        for (int i=0;i<A.size();i++){
            sum=sum+A.get(i);
        }
        if (A.size()==0){
            return 0;
        }
        else {
            result = (float) (sum / A.size());
            return result;
        }
    }

    public  int sosanh(float Coship4,float Coship5, float TTI, float Telecom ,ArrayList<RSSI>B){
        float min=10000;
        float tempCoship4, tempCoship5, tempTTI , tempTelecom;
        float sum;
        int result=50;

        for (int i=0;i<B.size();i++){

                tempCoship4=Coship4-B.get(i).RSSI_coship4;

                tempCoship5=Coship5-B.get(i).RSSI_coship5;

                tempTTI=TTI-B.get(i).RSSI_TTI;

                tempTelecom=Telecom-B.get(i).RSSI_Telecom;

            sum=Math.abs(tempCoship4)+Math.abs(tempCoship5)+Math.abs(tempTTI)+Math.abs(tempTelecom)*0;
            if (sum<min){
                min=sum;
                result=B.get(i).ID;
            }
        }
        return result;
    }
    public int IDreturn(){
        float ID_Coship4=avg(rssi_Coship4);
        float ID_COship5=avg(rssi_Coship5);
        float ID_TTI=avg(rssi_TTI);
        float ID_Telecom=avg(rssi_Telecom);
        return sosanh(ID_Coship4,ID_COship5,ID_TTI,ID_Telecom,databaseRSSI);

    }


}
