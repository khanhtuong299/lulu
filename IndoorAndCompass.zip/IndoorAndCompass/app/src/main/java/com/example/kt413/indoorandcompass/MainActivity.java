package com.example.kt413.indoorandcompass;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private Socket mSocket;
    {
        try {
            mSocket = IO.socket("https://khanhtuongindoor.herokuapp.com/");
        } catch (URISyntaxException e) {}
    }
    String UserName;
    String internet="off";

    //--------------------------------------------------------------------------------------------
    float totaldegrees=0;
    SensorManager sensorManager;
    Sensor sensor;
    private Sensor mAccelerometer;
    private Sensor mMagnetometer;
    private float[] mLastAccelerometer = new float[3];
    private float[] mLastMagnetometer = new float[3];
    private boolean mLastAccelerometerSet = false;
    private boolean mLastMagnetometerSet = false;
    private float[] rMat = new float[9];
    private float[] mOrientation = new float[3];
    TextView txt_compass;
    float mAzimuth;
    float mAzimuth_old=0;
    CompassView mCompass;
    //--------------------------------------------------------------------------------------------
    Canvas canvas;
    //--------------------------------------------------------------------------------------------
    AnimationCanvas animationCanvas;
    //float[] toadoX={89, 236, 389, 389, 389, 389, 389, 523, 503, 517, 663, 663, 663, 663, 663};
    //float[] toadoY={240, 240, 240, 448, 539, 721, 906, 906, 1016, 539, 240, 448, 539, 906, 1162};
    float[] toadoX={200,  367,  547,  547,  547,  547,  547,  719,  876,  876,  876};
    float[] toadoY={251,  251,  251,  457,  623,  828,  1043,  623,  623,  828,  1043};
    //--------------------------------------------------------------------------------------------
    TextView result;
    ImageButton bntReset;
    //--------------------------------------------------------------------------------------------
    SQLiteDatabase database;
    final String DATABASE_NAME="IndoorMapver4.sqlite";
    final String SQLiteString="SELECT * FROM IndoorMap";
    final String Coship4="58:87:e2:fb:4c:f4";                      //"18:d0:71:c6:43:c3";
    final String Coship5="58:87:e2:fb:4c:f5";                      //"68:89:c1:83:55:c0";
    final String TTI= "ac:6f:bb:19:0d:8e";                          //"00:1c:e0:5a:00:d7";
    final String Telecom= "98:fc:11:bd:a2:20";                      //"90:17:ac:19:53:e0";
    ArrayList<RSSI> databaseRSSI=new ArrayList<>();
    ArrayList<RSSI> tempRSSI=new ArrayList<>();
    int ID_old=0;
    //--------------------------------------------------------------------------------------------
    WifiManager wifiManager;
    ArrayList<Integer> rssi_Coship4=new ArrayList<>();
    ArrayList<Integer>rssi_Coship5=new ArrayList<>();
    ArrayList<Integer>rssi_TTI=new ArrayList<>();
    ArrayList<Integer> rssi_Telecom=new ArrayList<>();
    //--------------------------------------------------------------------------------------------
    Eulid eulid;
    //-------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ActionBar actionBar=getSupportActionBar();
        //actionBar.setDisplayHomeAsUpEnabled(true);
        //actionBar.setTitle("IPS Hydrid Wifi-BLE");
        //------------------------------------------
        //------------------------------------------
        UserName=getIntent().getStringExtra("USERNAME");
        internet=getIntent().getStringExtra("INTERNET");
        mSocket.connect();
        mSocket.emit("USER_NAME", UserName);
        mSocket.on("PING", recievePing);
        //------------------------------------------
        //checkBTPermissions();
        //------------------------------------------

        //------------------------------------------
        wifiManager = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        //------------------------------------------
        canvas=(Canvas)findViewById(R.id.myCanvas);
        mCompass=(CompassView)findViewById(R.id.myCompass);
        //------------------------------------------
        result=(TextView) findViewById(R.id.txtResult);
        txt_compass=(TextView)findViewById(R.id.txtGoclech);
        bntReset=(ImageButton)findViewById(R.id.imaReset);

        bntReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readDataTemp();
            }
        });
        //--------------------------------------------
        StartProgram();

    }

    @Override
    protected void onStart() {
        super.onStart();
        sensorManager=(SensorManager)this.getSystemService(SENSOR_SERVICE);
        sensor=sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        sensorManager.registerListener(this,sensor,1);
        mAccelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mMagnetometer=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        sensorManager.registerListener(this,mAccelerometer,1);
        sensorManager.registerListener(this,mMagnetometer,1);
    }

    //----------------------------------------------------------------------------------------------
    private Emitter.Listener recievePing=new Emitter.Listener() {
        @Override
        public void call(Object...  args) {
            JSONObject data = (JSONObject)  args[0];

        }
    };
    //----------------------------------------------------------------------------------------------
    private void intiloop(){
        rssi_Telecom.clear();
        rssi_Coship4.clear();
        rssi_Coship5.clear();
        rssi_TTI.clear();
        CountDownTimer scantimer=new CountDownTimer(4000,1200) {
            @Override
            public void onTick(long l) {
                ScanWF();
                result.setText("CO4 "+rssi_Coship4+" CO5 "+rssi_Coship5+"\nTTI "+rssi_TTI+
                        " Ly "+rssi_Telecom);
            }
            @Override
            public void onFinish() {
                eulid=new Eulid( tempRSSI, rssi_Coship4, rssi_Coship5, rssi_TTI, rssi_Telecom);
                int stt=eulid.IDreturn();
                result.setText(String.valueOf(stt));
                if (eulid.check()){

                    mSocket.emit("LOCATION", stt);

                    tempdabatbase(stt);

                    nextstep(ID_old,stt);


                    ID_old=stt;
                }
                else {
                    result.setText("no signal");
                }
            }
        };
        scantimer.start();
    }

    public void initfirst(){
        rssi_Telecom.clear();
        rssi_Coship4.clear();
        rssi_Coship5.clear();
        rssi_TTI.clear();
        CountDownTimer scantimer=new CountDownTimer(4000,1200) {
            @Override
            public void onTick(long l) {
                ScanWF();
                result.setText("Co4 "+rssi_Coship4+" Co5 "+rssi_Coship5+"\nTTI "+rssi_TTI+
                        " Ly "+rssi_Telecom);
            }
            @Override
            public void onFinish() {
                eulid=new Eulid( databaseRSSI, rssi_Coship4, rssi_Coship5, rssi_TTI, rssi_Telecom);
                result.setText(String.valueOf(eulid.IDreturn()));
                if (eulid.check()){
                    ID_old=eulid.IDreturn();
                    mSocket.emit("LOCATION", ID_old);
                    tempdabatbase(ID_old);
                    firststep(ID_old);
                    result.setText(tempRSSI.get(0).connect+"\n"+ String.valueOf(tempRSSI.get(0).ID)+"\n"+
                            String.valueOf(eulid.avg(rssi_Coship4))+"\n"+ String.valueOf(eulid.avg(rssi_Coship5))+"\n"+
                            String.valueOf(eulid.avg(rssi_TTI))+"\n"+ String.valueOf(eulid.avg(rssi_Telecom))+"\n"+
                            String.valueOf(eulid.IDreturn())
                    );
                }
                else {
                    result.setText("no signal");
                }

            }
        };
        scantimer.start();
    }

    public void loop(){
        intiloop();
        CountDownTimer looptimer= new CountDownTimer(3000,1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {

                loop();

            }
        };
        looptimer.start();
    }
    //----------------------------------------------------------------------------------------------
    public void StartProgram(){
        readDatabyRSSI();
        initfirst();
        loop();
    }
    //----------------------------------------------------------------------------------------------
    private void tempdabatbase(int stt){
        tempRSSI.clear();
        String connectID=databaseRSSI.get(stt).connect;
        String[] words=connectID.split("\\s");
        for (int i=0;i<words.length;i++){
            int k = Integer.parseInt(words[i]);
            tempRSSI.add(databaseRSSI.get(k));
        }
    }
    //----------------------------------------------------------------------------------------------

    @Override
    public void onSensorChanged(SensorEvent event) {

        switch (event.sensor.getType()){
            case Sensor.TYPE_ROTATION_VECTOR:
                SensorManager.getRotationMatrixFromVector(rMat, event.values);
                mAzimuth = (int) (Math.toDegrees(SensorManager.getOrientation(rMat, mOrientation)[0]) + 360) % 360;
                break;
            case Sensor.TYPE_ACCELEROMETER:
                System.arraycopy(event.values, 0, mLastAccelerometer, 0, event.values.length);
                mLastAccelerometerSet = true;
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                System.arraycopy(event.values, 0, mLastMagnetometer, 0, event.values.length);
                mLastMagnetometerSet = true;
                break;
            case Sensor.TYPE_GYROSCOPE:
                Long degrees_long = (Long) (Math.round(event.values[2] * 180 / Math.PI));
                float degrees = (float) degrees_long;
                totaldegrees+=degrees;
                canvas.degree=-totaldegrees*0.009f;
                canvas.invalidate();
        }
        if (mLastAccelerometerSet && mLastMagnetometerSet) {
            SensorManager.getRotationMatrix(rMat, null, mLastAccelerometer, mLastMagnetometer);
            SensorManager.getOrientation(rMat, mOrientation);
            mAzimuth = (float) (Math.toDegrees(SensorManager.getOrientation(rMat, mOrientation)[0]) + 360) % 360;
        }
        mAzimuth = Math.round(mAzimuth);
        mCompass.mdegree=-(mAzimuth-mAzimuth_old);
        mCompass.invalidate();
        mAzimuth_old=mAzimuth;

        String where = "NW";

        if (mAzimuth >= 350 || mAzimuth <= 10)
            where = "N";
        if (mAzimuth < 350 && mAzimuth > 280)
            where = "NW";
        if (mAzimuth <= 280 && mAzimuth > 260)
            where = "W";
        if (mAzimuth <= 260 && mAzimuth > 190)
            where = "SW";
        if (mAzimuth <= 190 && mAzimuth > 170)
            where = "S";
        if (mAzimuth <= 170 && mAzimuth > 100)
            where = "SE";
        if (mAzimuth <= 100 && mAzimuth > 80)
            where = "E";
        if (mAzimuth <= 80 && mAzimuth > 10)
            where = "NE";


        txt_compass.setText(mAzimuth + "° " + where);

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    //----------------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------------
    private void firststep(int i){
        animationCanvas=new AnimationCanvas(canvas);
        animationCanvas.firstPoint(toadoX[i],toadoY[i]);

    }
    private void nextstep(int i, int j){
        animationCanvas=new AnimationCanvas(canvas);
        animationCanvas.netxPoint(toadoX[i],toadoY[i],toadoX[j],toadoY[j],4);
    }
    //-------------------------------------------------------------------------------------------
    private void readDatabyRSSI(){
        database = Database.initDatabase(this, DATABASE_NAME);
        Cursor cursor = database.rawQuery(SQLiteString, null);
        for (int i=0; i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            int ID=cursor.getInt(0);
            float x=cursor.getFloat(1);
            float y=cursor.getFloat(2);
            float Coship4_temp=cursor.getFloat(3);
            float Coship5_temp=cursor.getFloat(4);
            float TTI_temp=cursor.getFloat(5);
            float Telecom_temp=cursor.getFloat(6);
            String connect=cursor.getString(7);
            databaseRSSI.add(new RSSI(ID,x,y,Coship4_temp,Coship5_temp,TTI_temp,Telecom_temp,connect));
        }
    }

    private void readDataTemp(){
        tempRSSI.clear();
        database = Database.initDatabase(this, DATABASE_NAME);
        Cursor cursor = database.rawQuery(SQLiteString, null);
        for (int i=0; i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            int ID=cursor.getInt(0);
            float x=cursor.getFloat(1);
            float y=cursor.getFloat(2);
            float Coship4_temp=cursor.getFloat(3);
            float Coship5_temp=cursor.getFloat(4);
            float TTI_temp=cursor.getFloat(5);
            float Telecom_temp=cursor.getFloat(6);
            String connect=cursor.getString(7);
            tempRSSI.add(new RSSI(ID,x,y,Coship4_temp,Coship5_temp,TTI_temp,Telecom_temp,connect));
        }
    }
    //----------------------------------------------------------------------------------------------
    public void ScanWF() {
        wifiManager.startScan();
        int sizewifi = wifiManager.getScanResults().size();
        for (int i = 0; i < sizewifi; i++) {
            ScanResult resultWF = wifiManager.getScanResults().get(i);
            switch (resultWF.BSSID) {
                case Coship4:
                    rssi_Coship4.add(resultWF.level);
                    break;
                case Coship5:
                    rssi_Coship5.add(resultWF.level);
                    break;
                case TTI:
                    rssi_TTI.add(resultWF.level);
                    break;
                case Telecom:
                    rssi_Telecom.add(resultWF.level);
                    break;
            }
        }
        result.setText(String.valueOf(rssi_Coship4));
    }
}