package com.example.kt413.indoorandcompass;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

/**
 * Created by kt413 on 12/3/2017.
 */

public class Launcher extends AppCompatActivity {

    EditText edtUserName;
    ImageButton bntUserName;
    ImageButton bntskip;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launcher);
        //checkBTPermissions();
        edtUserName  =(EditText)findViewById(R.id.edtUserName);
        bntUserName=(ImageButton)findViewById(R.id.bntSendUseName);
        bntskip=(ImageButton)findViewById(R.id.bntSkip);
        bntUserName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String UserName=edtUserName.getText().toString();
                String internet="on";
                if (UserName.equals("")==true){
                    Toast.makeText(Launcher.this,"Please input User Name",Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent i=new Intent(getApplicationContext(),MainActivity.class);
                    i.putExtra("USERNAME",UserName);
                    i.putExtra("INTERNET",internet);
                    startActivity(i);
                    overridePendingTransition(R.anim.push_down_in,R.anim.push_down_out);
                }
            }
        });
        bntskip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String internet="off";
                Intent i=new Intent(getApplicationContext(),MainActivity.class);
                i.putExtra("INTERNET",internet);
                startActivity(i);
                overridePendingTransition(R.anim.push_down_in,R.anim.push_down_out);
            }
        });
    }

    private void checkBTPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {
                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        }
    }

}
