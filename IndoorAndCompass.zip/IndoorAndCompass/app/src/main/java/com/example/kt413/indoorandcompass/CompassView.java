package com.example.kt413.indoorandcompass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by kt413 on 12/12/2017.
 */

public class CompassView extends View {

    float degree_building=15;
    Bitmap imgae_Background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
    Bitmap Compass = BitmapFactory.decodeResource(getResources(), R.drawable.compass);
    int ngang_Backgourd=imgae_Background.getWidth();
    int doc_Background=imgae_Background.getHeight();
    int ngang_compass=Compass.getWidth();
    int doc_compass=Compass.getHeight();
    Paint mPaint;
    float ngang_BackgroundOR=150;
    float doc_BackgroundOR=150;
    float ngang_compassOR=90;
    float doc_compassOR=106;
    Matrix matrixBackground;
    Matrix matrixCompass;
    float mdegree=0;

    public CompassView(Context context) {
        super(context);
        intPaint();
    }

    public CompassView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        intPaint();
    }

    public CompassView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        intPaint();
    }

    private void intPaint(){
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(30);
        matrixBackground = new Matrix();
        matrixBackground.postScale((float)(ngang_BackgroundOR/ngang_Backgourd),(float)(doc_BackgroundOR/doc_Background));
        matrixBackground.postTranslate(-ngang_BackgroundOR/2,-doc_BackgroundOR/2);
        matrixCompass=new Matrix();
        matrixCompass.postScale((float)(ngang_compassOR/ngang_compass),(float)(doc_compassOR/doc_compass));
        matrixCompass.postTranslate(-ngang_compassOR/2,-doc_compassOR/2-10);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(getWidth()/2,getHeight()/2);
        canvas.drawBitmap(imgae_Background,matrixBackground,mPaint);
        matrixCompass.postRotate(mdegree);
        canvas.drawBitmap(Compass,matrixCompass,mPaint);
    }
}
